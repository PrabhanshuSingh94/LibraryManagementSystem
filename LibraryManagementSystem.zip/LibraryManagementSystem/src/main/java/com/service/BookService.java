package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.BookDetails;
import com.repository.BookRepository;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {
    
    @Autowired
    private BookRepository bookRepository;

    public List<BookDetails> findAllBookd(){
    	return bookRepository.findAll();
    }
    
    // Save a book
    public BookDetails saveBook(BookDetails book) {
        return bookRepository.save(book);
    }

    // Find books by name and author
    public List<BookDetails> findBooksByName(String bookName) {
        return bookRepository.findByBookName(bookName); // Returns a list of books
    }
}