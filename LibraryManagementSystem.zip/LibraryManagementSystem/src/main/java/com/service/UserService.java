package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.User;
import com.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	public UserRepository userRepo;
	
	public List<User> getAllData() {
		return userRepo.findAll();		
	}
	
	public User registration(User userDetails) {
		return userRepo.save(userDetails);
	}
	
	 public User login(String username, String password) {
		 Optional<User> userName = userRepo.findById(username);
	     

	        // Check if the user exists and the password matches (no encryption)
	        if (userName.isPresent()) {
	            User user = userName.get();
	            if (user.getPassword().equals(password)) {
	                return user;  // Successful login
	            }
	        }

	        // Return null if login fails
	        return null;
	    }

}
