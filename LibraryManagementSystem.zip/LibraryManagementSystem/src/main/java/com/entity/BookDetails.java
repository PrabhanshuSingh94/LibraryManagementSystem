package com.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class BookDetails {
	@Id
	public String serial;
	public String bookName;
	public String author;
	public String available;
	public String getSerial() {
		return serial;
	}
	public void setSerial(String serial) {
		this.serial = serial;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getAvailable() {
		return available;
	}
	public void setAvailable(String available) {
		this.available = available;
	}
	
	
	
	

}
