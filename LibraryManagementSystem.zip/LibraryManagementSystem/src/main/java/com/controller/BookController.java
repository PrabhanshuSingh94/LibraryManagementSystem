package com.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import com.entity.BookDetails;
import com.service.BookService;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://127.0.0.1:5500/src/main/resources/templates/")
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;
    
    @GetMapping("showAllBook")
    public List<BookDetails> showAllBooks(){
    	return bookService.findAllBookd();
    }

    // Register a new book
    @PostMapping("/add")
    public BookDetails addBook(@RequestBody BookDetails book) {
        return bookService.saveBook(book);
    }

    // Get books by name and author
    @GetMapping("/search")
    public List<BookDetails> getBooksByName(@RequestParam String bookName) {
        return bookService.findBooksByName(bookName);
    }
}