package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.User;
import com.service.UserService;

@RestController
@CrossOrigin(origins = "http://127.0.0.1:5500/src/main/resources/templates/")
public class AuthenticationController {
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/register")
	public ResponseEntity<User> registerUser(@RequestBody User userDetails) {
		User registeredUser = userService.registration(userDetails);
		return ResponseEntity.ok(registeredUser); // Return the registered user as JSON
	}
	
	@PostMapping("/login")
	public ResponseEntity<String> login(@RequestBody User loginRequest) {
		User user = userService.login(loginRequest.getUserId(), loginRequest.getPassword());
		if (user != null) {
			return ResponseEntity.ok("Login successful!"); // Use ResponseEntity for consistency
		} else {
			return ResponseEntity.status(401).body("Invalid username or password."); // Return 401 status
		}
	}
	
	@GetMapping("/fetch")
	public List<User> getStudents(){
		return userService.getAllData();
	}
}
